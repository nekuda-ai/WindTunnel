/**
 * The pinned WebMCP spec surface — the ONLY module that knows the raw browser API.
 *
 * Pinned against the WebMCP editor's draft as of 2026-07
 * (https://webmachinelearning.github.io/webmcp/):
 *
 *   - `document.modelContext` is the surface (Chrome 150+). `navigator.modelContext`
 *     is deprecated but is the only surface on Chrome 149, so resolution reads
 *     `document` first and falls back — `??` picks exactly one object, so a browser
 *     exposing both never double-registers.
 *   - `registerTool(tool, { signal })` returns a promise that settles when the
 *     registration completes; it rejects on a duplicate name, an invalid tool, an
 *     inactive document, or an abort.
 *   - Unregistration happens ONLY by aborting the `AbortSignal` passed at
 *     registration. `unregisterTool()` and `provideContext()` are dead APIs and are
 *     never referenced.
 *   - Tool names: 1–128 chars of [A-Za-z0-9_\-.].
 *   - `annotations.readOnlyHint` / `annotations.untrustedContentHint`.
 *
 * The draft breaks monthly; absorbing that churn is this module's job (R23). All
 * other modules — and all plugin-generated code — target `ModelContextLike`, never
 * the raw API.
 */

export interface ToolAnnotations {
  /** The tool does not modify page or user state. */
  readOnlyHint?: boolean;
  /** The tool's output can contain untrusted (user or third-party) data. */
  untrustedContentHint?: boolean;
}

/** The tool shape `registerTool` accepts (`ModelContextTool` in the draft IDL). */
export interface SpecTool {
  name: string;
  title?: string;
  description: string;
  inputSchema?: Record<string, unknown>;
  annotations?: ToolAnnotations;
  execute(input: Record<string, unknown>): Promise<unknown>;
}

export interface RegisterToolOptions {
  /** Aborting unregisters the tool — the spec's only unregistration mechanism. */
  signal?: AbortSignal;
}

/**
 * The slice of the native surface the SDK uses, typed to the draft contract:
 * `registerTool` returns a promise. Pre-draft surfaces that return nothing are a
 * runtime concern only — the SDK normalizes via `Promise.resolve` at the call
 * site, never by widening this type.
 */
export interface ModelContextLike {
  registerTool(tool: SpecTool, options?: RegisterToolOptions): Promise<void>;
}

interface GlobalWithModelContext {
  document?: { modelContext?: ModelContextLike };
  navigator?: { modelContext?: ModelContextLike };
}

/**
 * Resolve the page's WebMCP surface; `undefined` on non-supporting browsers.
 * Injectable global scope for tests.
 */
export function resolveModelContext(g: object = globalThis): ModelContextLike | undefined {
  const scope = g as GlobalWithModelContext;
  return scope.document?.modelContext ?? scope.navigator?.modelContext;
}
