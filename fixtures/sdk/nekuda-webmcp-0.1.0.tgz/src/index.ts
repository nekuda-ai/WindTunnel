/**
 * @nekuda/webmcp — the phase-1 WebMCP SDK: a thin wrapper over the plain-JS WebMCP
 * spec (https://webmachinelearning.github.io/webmcp/) for registering and
 * unregistering tools. Plugin-generated code targets THIS surface, never the raw
 * `document.modelContext` API — the wrapper pins a spec version and absorbs the
 * draft's monthly breaking churn (R23).
 *
 * The seam contract (what plugin codegen may rely on):
 *
 * 1. `defineTool(definition)` is side-effect-free: it validates eagerly, freezes,
 *    and returns the tool. Nothing touches the browser until `registerTools`.
 * 2. `stableKey` lives on the definition, next to `name`. It is the
 *    developer-authored durable identity — it survives renames and codegen re-runs
 *    and is never sent to the browser.
 * 3. Registration lifecycle: `registerTools(tools, { signal?, tracking? })` registers on call
 *    and returns `{ ready, unregister, signal }`. Unregistration happens ONLY via
 *    `unregister()` or the external signal aborting (page teardown / SPA unmount).
 *    Browsers without a WebMCP surface are a graceful no-op (`state: "unsupported"`).
 * 4. "Connect later without rewrite": generated modules only `defineTool` and
 *    EXPORT tools; one entry module calls `registerTools`. Connecting a site to the
 *    platform later (API key, telemetry) changes wrapper internals and config only —
 *    generated modules and their imports do not change. See `examples/add-to-cart.ts`.
 * 5. OTEL auto-instrumentation, API keys, and trace export are NOT part of this
 *    surface and will never leak into it.
 * 6. Anonymous tool-call tracking is opt-in via `registerTools`'s `tracking`
 *    option (see `TrackingOptions`). Off by default — no config means no
 *    tracking and zero behavior change. When enabled it resolves an anonymous
 *    visitor/session identity and emits a request+response event per tool call.
 *    The transport is still a `console.log` stub; swapping it for a beacon
 *    endpoint is wrapper-internal and will not change this surface. See
 *    `src/tracking.ts` and `examples/add-to-cart.ts`.
 */

export { type AnyWebMCPTool, type ToolDefinition, type WebMCPTool, defineTool } from "./define";
export {
  type RegisterToolsOptions,
  type ToolRegistration,
  type ToolRegistrationResult,
  type ToolRegistrationState,
  registerTools,
} from "./register";
export {
  type ModelContextLike,
  type RegisterToolOptions,
  type SpecTool,
  type ToolAnnotations,
  resolveModelContext,
} from "./spec";
export type { TrackingEvent, TrackingOptions } from "./tracking";
