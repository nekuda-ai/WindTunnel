/**
 * Anonymous visitor/session tracking for WebMCP tool calls. Opt-in via the
 * `tracking` option on `registerTools`; `TrackingOptions.disabled` is the
 * consent gate.
 *
 * This module owns three things: anonymous identity, event payload assembly
 * (`buildEventPayload`), and emission (`track`).
 *
 * Identity is intentionally minimal and PII-free: random UUIDs only, namespaced
 * per customer so a shared origin never mixes customers. Event *payloads* are a
 * separate matter — page URL, tool `input`, and `response` are captured verbatim
 * and may carry PII; redaction is a concern for the future `/collect` transport,
 * not this `console.log` stub.
 *
 * - `visitorId` lives in `localStorage` and is stable across visits.
 * - `sessionId` lives in `sessionStorage` and is refreshed by a `last_seen`
 *   timestamp; after `SESSION_TIMEOUT_MS` of inactivity a new session is minted.
 *
 * Browser storage can be absent (non-DOM env) or throw (privacy mode). Every
 * access is guarded, and on failure the module falls back to per-page-load
 * in-memory IDs so identity resolution never throws.
 *
 * Transport is still a stub: `track()` `console.log`s each event. Swapping it
 * for `navigator.sendBeacon` (with a `fetch keepalive` fallback) once the
 * `/collect` endpoint exists is the only remaining work — see the TODO on
 * `track()`. Everything else in the tracking design is implemented.
 */

/** New session after this much inactivity (30 minutes), per the design doc. */
const SESSION_TIMEOUT_MS = 30 * 60 * 1000;

const visitorKey = (customerId: string) => `webmcp:${customerId}:visitor_id`;
const sessionKey = (customerId: string) => `webmcp:${customerId}:session_id`;
const lastSeenKey = (customerId: string) => `webmcp:${customerId}:last_seen`;

/** Per-page-load fallback IDs, keyed by customerId, used when storage fails. */
const memoryVisitor = new Map<string, string>();
const memorySession = new Map<string, string>();

/** Read a browser storage area, tolerating both absence and throwing getters. */
function storage(kind: "localStorage" | "sessionStorage"): Storage | null {
  try {
    return ((globalThis as Record<string, unknown>)[kind] as Storage | undefined) ?? null;
  } catch {
    return null;
  }
}

function readItem(store: Storage | null, key: string): string | null {
  if (!store) return null;
  try {
    return store.getItem(key);
  } catch {
    return null;
  }
}

function writeItem(store: Storage | null, key: string, value: string): boolean {
  if (!store) return false;
  try {
    store.setItem(key, value);
    return true;
  } catch {
    return false;
  }
}

/** Return the cached fallback ID for this page load, seeding it on first use. */
function fallbackId(cache: Map<string, string>, customerId: string, candidate: string): string {
  const cached = cache.get(customerId);
  if (cached) return cached;
  cache.set(customerId, candidate);
  return candidate;
}

/**
 * A v4 UUID that resolves in every context. `crypto.randomUUID` is
 * secure-context-only — `undefined` on plain `http://` pages — so we fall back
 * to `crypto.getRandomValues` (available in insecure contexts) and finally
 * `Math.random`, preserving this module's "identity resolution never throws"
 * guarantee even on non-HTTPS sites.
 */
function randomId(): string {
  const c = (globalThis as { crypto?: Partial<Crypto> }).crypto;
  if (typeof c?.randomUUID === "function") {
    try {
      return c.randomUUID();
    } catch {
      // Fall through to the byte-based builder below.
    }
  }
  const bytes = new Uint8Array(16);
  let filled = false;
  try {
    if (typeof c?.getRandomValues === "function") {
      c.getRandomValues(bytes);
      filled = true;
    }
  } catch {
    // getRandomValues can throw; Math.random backfills below.
  }
  const hex = Array.from(bytes, (b, i) => {
    const byte = filled ? b : Math.floor(Math.random() * 256);
    // Set the version (4) and variant bits per RFC 4122.
    const v = i === 6 ? (byte & 0x0f) | 0x40 : i === 8 ? (byte & 0x3f) | 0x80 : byte;
    return v.toString(16).padStart(2, "0");
  }).join("");
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
}

/** Stable anonymous visitor ID, persisted in `localStorage` across visits. */
export function getOrCreateVisitorId(customerId: string): string {
  const store = storage("localStorage");
  const key = visitorKey(customerId);
  const existing = readItem(store, key);
  if (existing) return existing;

  const id = randomId();
  if (writeItem(store, key, id)) return id;
  return fallbackId(memoryVisitor, customerId, id);
}

/**
 * Journey session ID in `sessionStorage`. Reuses the existing session while
 * `last_seen` is within the timeout, otherwise mints a new one. Every call
 * refreshes `last_seen`.
 */
export function getOrCreateSessionId(customerId: string): string {
  const store = storage("sessionStorage");
  const now = Date.now();
  const existing = readItem(store, sessionKey(customerId));
  const lastSeen = Number(readItem(store, lastSeenKey(customerId)));
  const active =
    existing !== null && Number.isFinite(lastSeen) && now - lastSeen < SESSION_TIMEOUT_MS;

  const id = active ? existing : randomId();
  const persisted =
    writeItem(store, sessionKey(customerId), id) &&
    writeItem(store, lastSeenKey(customerId), String(now));
  if (persisted) return id;
  return fallbackId(memorySession, customerId, id);
}

/**
 * Configures tool-call tracking for a `registerTools` batch.
 *
 * `customerId` namespaces identity storage and appears on every event.
 * `disabled: true` is the consent gate — it skips all identity creation,
 * storage writes, and event emission entirely.
 */
export interface TrackingOptions {
  customerId: string;
  disabled?: boolean;
}

/**
 * A single tracking event. Identity + timing fields are always present; page
 * fields are best-effort (absent in a non-DOM env); event-specific data (e.g.
 * `toolStableKey`, `input`, `response`) is spread in by the caller.
 */
export interface TrackingEvent {
  /** Dedup key, unique per event. */
  eventId: string;
  customerId: string;
  visitorId: string;
  sessionId: string;
  eventName: string;
  /** Event time as an ISO-8601 string. */
  ts: string;
  siteOrigin?: string;
  url?: string;
  path?: string;
  referrer?: string;
  title?: string;
  [key: string]: unknown;
}

/** Best-effort page context; empty in a non-DOM env or if the globals throw. */
function pageFields(): Partial<TrackingEvent> {
  const fields: Partial<TrackingEvent> = {};
  try {
    const loc = (globalThis as { location?: Partial<Location> }).location;
    if (loc) {
      if (loc.origin) fields.siteOrigin = loc.origin;
      if (loc.href) fields.url = loc.href;
      if (loc.pathname) fields.path = loc.pathname;
    }
    const doc = (globalThis as { document?: Partial<Document> }).document;
    if (doc) {
      if (doc.referrer !== undefined) fields.referrer = doc.referrer;
      if (doc.title !== undefined) fields.title = doc.title;
    }
  } catch {
    // A hostile/partial DOM must never break event building.
  }
  return fields;
}

/** Assemble a tracking event from resolved identity, an event name, and extra data. */
export function buildEventPayload(params: {
  customerId: string;
  visitorId: string;
  sessionId: string;
  eventName: string;
  data?: Record<string, unknown>;
}): TrackingEvent {
  return {
    eventId: randomId(),
    customerId: params.customerId,
    visitorId: params.visitorId,
    sessionId: params.sessionId,
    eventName: params.eventName,
    ts: new Date().toISOString(),
    ...pageFields(),
    ...params.data,
  };
}

/**
 * Emit a tracking event. No-op when tracking is disabled. Resolves identity,
 * builds the payload, and logs it. Wrapped end-to-end in try/catch so tracking
 * can never break the caller (tool execution owns correctness, not telemetry).
 *
 * TODO: swap the `console.log` stub for `navigator.sendBeacon` with a
 * `fetch(..., { keepalive: true })` fallback once the `/collect` endpoint exists.
 */
export function track(
  options: TrackingOptions,
  eventName: string,
  data?: Record<string, unknown>,
): void {
  if (options.disabled) return;
  try {
    const event = buildEventPayload({
      customerId: options.customerId,
      visitorId: getOrCreateVisitorId(options.customerId),
      sessionId: getOrCreateSessionId(options.customerId),
      eventName,
      data,
    });
    console.log("[webmcp:tracking]", event);
  } catch {
    // Telemetry is best-effort; failures are swallowed by design.
  }
}
