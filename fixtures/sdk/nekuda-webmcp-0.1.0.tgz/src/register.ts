import type { AnyWebMCPTool } from "./define";
import { type ModelContextLike, type SpecTool, resolveModelContext } from "./spec";
import { type TrackingOptions, track } from "./tracking";

/**
 * Per-tool outcome of a `registerTools` call:
 *   - `registered`   — live on the page's WebMCP surface
 *   - `unsupported`  — this browser has no WebMCP surface; nothing was registered
 *   - `aborted`      — the registration's lifetime ended before/while registering
 *   - `failed`       — the native surface rejected (e.g. duplicate name)
 */
export type ToolRegistrationState = "registered" | "unsupported" | "aborted" | "failed";

export interface ToolRegistrationResult {
  stableKey: string;
  name: string;
  state: ToolRegistrationState;
  error?: unknown;
}

export interface RegisterToolsOptions {
  /**
   * External lifetime for the registration (e.g. a component's unmount signal).
   * Aborting it unregisters every tool in this batch, same as `unregister()`.
   */
  signal?: AbortSignal;
  /** Injectable surface for tests; defaults to the page's `document.modelContext`. */
  modelContext?: ModelContextLike;
  /**
   * Enables anonymous tool-call tracking for this batch. Each tool invocation
   * emits a `tool_call_request` event before its handler runs and a
   * `tool_call_response` event after. Omit it (the default) for zero tracking
   * and no behavior change; `disabled: true` is the consent gate.
   */
  tracking?: TrackingOptions;
}

export interface ToolRegistration {
  /**
   * Settles when every tool's native registration settles. Never rejects — per-tool
   * outcomes (including failures) are reported in the results, so one bad tool
   * cannot mask the rest.
   */
  ready: Promise<ToolRegistrationResult[]>;
  /** Unregister every tool in this batch. Idempotent. */
  unregister(): void;
  /** The signal carrying this registration's lifetime (aborted once unregistered). */
  signal: AbortSignal;
}

interface ContentResult {
  content: unknown[];
}

function isContentResult(value: unknown): value is ContentResult {
  return (
    typeof value === "object" &&
    value !== null &&
    Array.isArray((value as { content?: unknown }).content)
  );
}

/**
 * Normalize a developer `execute` return value to the content shape agents expect:
 * strings become one text block, other values are JSON-stringified, and a
 * ready-made `{ content: [...] }` result passes through verbatim.
 */
function normalizeResult(value: unknown): unknown {
  if (isContentResult(value)) return value;
  const text = typeof value === "string" ? value : JSON.stringify(value ?? null);
  return { content: [{ type: "text", text }] };
}

/** Adapt a defined tool to the pinned spec shape (drops `stableKey` — never wired). */
function toSpecTool(tool: AnyWebMCPTool, tracking?: TrackingOptions): SpecTool {
  return {
    name: tool.name,
    ...(tool.title !== undefined ? { title: tool.title } : {}),
    description: tool.description,
    ...(tool.inputSchema !== undefined ? { inputSchema: tool.inputSchema } : {}),
    ...(tool.annotations !== undefined ? { annotations: tool.annotations } : {}),
    async execute(input) {
      // `track` swallows its own errors, so telemetry can never break execution.
      const identity = { toolStableKey: tool.stableKey, toolName: tool.name };
      if (tracking) track(tracking, "tool_call_request", { ...identity, input });
      try {
        // Errors propagate unchanged — the agent surface owns error presentation.
        const response = normalizeResult(await tool.execute(input));
        if (tracking) track(tracking, "tool_call_response", { ...identity, response });
        return response;
      } catch (error) {
        if (tracking)
          track(tracking, "tool_call_response", {
            ...identity,
            error: error instanceof Error ? error.message : String(error),
          });
        throw error;
      }
    },
  };
}

/** Duplicate names (or stableKeys) in one batch are an authoring/codegen bug. */
function assertUniqueIdentities(tools: readonly AnyWebMCPTool[]): void {
  const names = new Set<string>();
  const keys = new Set<string>();
  for (const tool of tools) {
    if (names.has(tool.name)) {
      throw new TypeError(`registerTools: duplicate tool name "${tool.name}"`);
    }
    if (keys.has(tool.stableKey)) {
      throw new TypeError(`registerTools: duplicate stableKey "${tool.stableKey}"`);
    }
    names.add(tool.name);
    keys.add(tool.stableKey);
  }
}

/**
 * Register a batch of `defineTool` tools on the page's WebMCP surface.
 *
 * Lifecycle: registration starts immediately; the tools stay live until
 * `unregister()` is called or the external `options.signal` aborts (both funnel
 * into one internal `AbortController`, the spec's only unregistration mechanism).
 * On browsers without a WebMCP surface this is a graceful no-op — generated code
 * can run unconditionally on every page.
 */
export function registerTools(
  tools: readonly AnyWebMCPTool[],
  options: RegisterToolsOptions = {},
): ToolRegistration {
  assertUniqueIdentities(tools);

  const controller = new AbortController();
  const external = options.signal;
  if (external) {
    if (external.aborted) controller.abort(external.reason);
    else
      external.addEventListener("abort", () => controller.abort(external.reason), { once: true });
  }

  const modelContext = options.modelContext ?? resolveModelContext();

  const result = (
    tool: AnyWebMCPTool,
    state: ToolRegistrationState,
    error?: unknown,
  ): ToolRegistrationResult => ({
    stableKey: tool.stableKey,
    name: tool.name,
    state,
    ...(error !== undefined ? { error } : {}),
  });

  const ready = Promise.all(
    tools.map(async (tool) => {
      if (!modelContext) return result(tool, "unsupported");
      if (controller.signal.aborted) return result(tool, "aborted");
      try {
        // Promise.resolve normalizes a pre-draft surface that returns void — the
        // draft contract (Promise) stays pinned in the type, tolerance stays here.
        await Promise.resolve(
          modelContext.registerTool(toSpecTool(tool, options.tracking), {
            signal: controller.signal,
          }),
        );
        return result(tool, "registered");
      } catch (error) {
        // A rejection after our own abort is the unregistration mechanism working,
        // not a failure — so no error is reported for it.
        if (controller.signal.aborted) return result(tool, "aborted");
        return result(tool, "failed", error);
      }
    }),
  );

  return {
    ready,
    signal: controller.signal,
    unregister() {
      controller.abort();
    },
  };
}
