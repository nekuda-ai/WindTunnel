import type { ToolAnnotations } from "./spec";

/** Spec rule: tool names are 1–128 chars of ASCII alphanumerics, `_`, `-`, `.`. */
const NAME_PATTERN = /^[A-Za-z0-9_.-]{1,128}$/;

/**
 * A developer-authored (or plugin-generated) tool declaration. Declaring is
 * side-effect-free — nothing touches the browser until `registerTools`.
 */
export interface ToolDefinition<TInput extends Record<string, unknown> = Record<string, unknown>> {
  /**
   * Developer-authored durable identity. The WebMCP `name` is the wire identity and
   * may be renamed freely; `stableKey` is what the platform keys on when the site is
   * later connected (analytics continuity, claiming), so it must survive renames and
   * codegen re-runs. It is never sent to the browser API.
   */
  stableKey: string;
  /**
   * WebMCP tool name: 1–128 chars of [A-Za-z0-9_\-.]. Optional — defaults to
   * `stableKey` when omitted, so a tool needs an explicit name only when its wire
   * identity should differ from its durable key.
   */
  name?: string;
  /** Optional human-readable display name. */
  title?: string;
  /** What the tool does, for the agent. Required and non-empty per spec. */
  description: string;
  /** JSON Schema for `execute`'s input, as a plain object. */
  inputSchema?: Record<string, unknown>;
  annotations?: ToolAnnotations;
  /**
   * The page-owned behavior. May return anything JSON-serializable, a plain string,
   * or a ready-made `{ content: [...] }` result — the SDK normalizes for the agent.
   * Thrown errors propagate to the agent unchanged.
   */
  execute(input: TInput): unknown;
}

declare const defined: unique symbol;

/**
 * A validated, frozen tool — the only thing `registerTools` accepts. `name` is
 * always resolved (falling back to `stableKey`), so it is required here.
 */
export type WebMCPTool<TInput extends Record<string, unknown> = Record<string, unknown>> = Readonly<
  ToolDefinition<TInput> & { name: string }
> & { readonly [defined]: true };

/** `WebMCPTool` erased of its input type, for heterogeneous collections. */
export type AnyWebMCPTool = WebMCPTool<any>;

function fail(field: string, problem: string): never {
  throw new TypeError(`defineTool: ${field} ${problem}`);
}

function isPlainObject(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

/**
 * Validate and freeze a tool definition. Validation is eager and throws `TypeError`
 * so an invalid tool fails at module-evaluation time (an authoring/codegen bug),
 * not at registration time on some visitor's browser.
 */
export function defineTool<TInput extends Record<string, unknown> = Record<string, unknown>>(
  definition: ToolDefinition<TInput>,
): WebMCPTool<TInput> {
  const { stableKey, description, inputSchema, execute } = definition;

  if (typeof stableKey !== "string" || stableKey.trim() === "") {
    fail("stableKey", "must be a non-empty string (the durable identity the platform keys on)");
  }
  // `name` is the wire identity; when omitted it falls back to `stableKey`. Either
  // way the resolved value must satisfy the spec's name pattern.
  const nameOmitted = definition.name === undefined;
  const name = definition.name ?? stableKey;
  if (typeof name !== "string" || !NAME_PATTERN.test(name)) {
    // Point at the field the author actually set: when `name` is omitted the
    // resolved value came from `stableKey`, so blame that instead.
    const field = nameOmitted ? "stableKey" : "name";
    const suffix = nameOmitted ? " when used as the wire name, or set an explicit `name`" : "";
    fail(field, `must be 1-128 chars of [A-Za-z0-9_\\-.]${suffix} (got ${JSON.stringify(name)})`);
  }
  if (typeof description !== "string" || description.trim() === "") {
    fail("description", "must be a non-empty string");
  }
  if (inputSchema !== undefined && !isPlainObject(inputSchema)) {
    fail("inputSchema", "must be a plain JSON Schema object when present");
  }
  if (typeof execute !== "function") {
    fail("execute", "must be a function");
  }

  return Object.freeze({ ...definition, name }) as WebMCPTool<TInput>;
}
